class PersonalListItem
{
    constructor(siteId, postId, md5, tags)
    {
        this.siteId = siteId;
        this.postId = postId;
        this.md5 = md5;
        this.tags = tags;
    }
}